/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('vaninfo', {
    VanNO: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    VinNumber: {
      type: DataTypes.STRING(50),
      allowNull: true,
      unique: true
    },
    CurentMileage: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    Make: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    Model: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    WareHouse: {
      type: DataTypes.STRING(50),
      allowNull: true
    },
    DateOfCreation: {
      type: DataTypes.DATEONLY,
      allowNull: true
    }
  }, {
    tableName: 'vaninfo'
  });
};
