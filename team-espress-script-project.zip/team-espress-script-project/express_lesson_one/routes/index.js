var express = require('express');
var router = express.Router();
const mysql = require('mysql2');
var models = require('../models');

var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Minniemo9Mister#@$%',
  database: 'sakila'
});

connection.connect(function(err) {
  if (err) {
    console.error(err.message);
    return;
  }
  console.log('connected to the database');
});

/* GET home page. */
const van = `SELECT * FROM VanInfo`;

router.get('/vanInfo', function(req, res, next) {
  connection.query(van, function(err, result) {
    res.render('van', {
      van: result
    });
  });
});

router.post('/vanInfo', function(req, res, next) {
  console.log(req.body);
  const newVan = {
    VanNO: req.body.VanNO,
    VinNumber: req.body.VinNumber,
    CurentMileage: req.body.CurentMileage,
    Make: req.body.Make,
    Model: req.body.Model,
    WareHouse: req.body.WareHouse
  };

  const selectVan = `SELECT * 
  FROM vanInfo
  WHERE VanNO = '${newVan.VanNO}'
  AND VinNumber = ${newVan.VinNumber}
  AND CurentMileage = ${newVan.CurentMileage}
  AND Make = ${newVan.Make}
  AND Model = ${newVan.Model}
  AND WareHouse = ${newVan.WareHouse}`;

  connection.query(selectVan, function(result){
    if (result.length > 0){ 
      res.send('That Van already exists');
    } else {
      let newVanQuery = `INSERT INTO vanInfo (VanNO, VinNumber, CurentMileage, Make, Model, WareHouse)
      VALUES('${newVan.VanNO}', '${newVan.VinNumber}', '${newVan.CurentMileage}','${newVan.Make}', '${newVan.Model}', '${newVan.WareHouse}')`;
      
      connection.query(newVanQuery, function(err, insertResult) {
        if (err) {
          res.render('error', { message: 'Oops, something went wrong!'});
        } else {
          res.redirect('/vanInfo');
        }
      });
    }
  });
});

router.get('/vanInfo/:id', function(req, res, next) {
  let vanInfoId = parseInt(req.params.id);
  console.log(vanInfoId);

  let idQuery = `SELECT * FROM Vaninfo WHERE VanNO=${vanInfoId} `;

  connection.query(idQuery, (err, result) => {
    if (err) {
      console.log(err.message);
      next();
      return;
    }
    if (result.length > 0){
      res.render('index', { vanInfo: result[0] });
    } else {
      res.send('Van does not exist yet');
    }
  });
});

router.get('/vaninfo', function(req, res, next){
  models.vanInfo
  .findAll({include: [{model: models.VanNO}]})
  .then(vansFound => {
    res.setHeader('Content-Type', 'application/json');
    res,send(JSON.stringify(vansFound));
  });
});

module.exports = router;